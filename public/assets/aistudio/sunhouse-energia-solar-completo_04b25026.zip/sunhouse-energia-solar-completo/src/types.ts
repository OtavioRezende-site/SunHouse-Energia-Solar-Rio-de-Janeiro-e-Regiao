export type PropertyType = 'Casa' | 'Comércio' | 'Outro';

export type BillRange = 
  | 'Até R$300' 
  | 'R$301–600' 
  | 'R$601–1.000' 
  | 'Acima de R$1.000' 
  | 'Prefiro informar depois';

export interface LeadFormData {
  nome: string;
  whatsapp: string;
  cidade: string;
  tipoImovel: PropertyType;
  faixaConta: BillRange;
  observacao?: string;
}

export interface ReviewItem {
  texto: string;
  data: string;
  fonte: string;
}

export interface FAQItem {
  id: string;
  pergunta: string;
  resposta: string;
}

export interface ProjectEvidence {
  id: string;
  arquivo: string;
  titulo: string;
  categoria: 'Residencial' | 'Comercial' | 'Destaque';
  cidade: string;
  legendaSegura: string;
  origemInstagramUrl: string;
  detalhes?: string;
}
